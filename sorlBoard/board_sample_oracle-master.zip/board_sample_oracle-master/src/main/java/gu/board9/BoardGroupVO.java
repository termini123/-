package gu.board9;

public class BoardGroupVO {

    private String bgno; 
    private String bgname; 
    private String bglevel; 
    private String bgparent; 
    private String bgdeleteflag; 
    private String bgused; 
    private String bgreply; 
    private String bgreadonly; 
    private String bgdate; 

    public String getBgno() {
        return bgno;
    }

    public void setBgno(String bgno) {
        this.bgno = bgno;
    }

    public String getBgname() {
        return bgname;
    }

    public void setBgname(String bgname) {
        this.bgname = bgname;
    }

    public String getBglevel() {
        return bglevel;
    }

    public void setBglevel(String bglevel) {
        this.bglevel = bglevel;
    }

    public String getBgparent() {
        return bgparent;
    }

    public void setBgparent(String bgparent) {
        this.bgparent = bgparent;
    }

    public String getBgdeleteflag() {
        return bgdeleteflag;
    }

    public void setBgdeleteflag(String bgdeleteflag) {
        this.bgdeleteflag = bgdeleteflag;
    }

    public String getBgused() {
        return bgused;
    }

    public void setBgused(String bgused) {
        this.bgused = bgused;
    }

    public String getBgreply() {
        return bgreply;
    }

    public void setBgreply(String bgreply) {
        this.bgreply = bgreply;
    }

    public String getBgreadonly() {
        return bgreadonly;
    }

    public void setBgreadonly(String bgreadonly) {
        this.bgreadonly = bgreadonly;
    }

    public String getBgdate() {
        return bgdate;
    }

    public void setBgdate(String bgdate) {
        this.bgdate = bgdate;
    }
}
