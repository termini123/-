package gu.board5;

public class BoardReplyVO {

    private String brdno;
    private String reno;
    private String rewriter;
    private String redeleteflag;
    private String rememo;
    private String redate;
    
    public String getBrdno() {
        return brdno;
    }
    
    public void setBrdno(String brdno) {
        this.brdno = brdno;
    }
    
    public String getReno() {
        return reno;
    }
    
    public void setReno(String reno) {
        this.reno = reno;
    }
    
    public String getRewriter() {
        return rewriter;
    }
    
    public void setRewriter(String rewriter) {
        this.rewriter = rewriter;
    }
    
    public String getRedeleteflag() {
        return redeleteflag;
    }
    
    public void setRedeleteflag(String redeleteflag) {
        this.redeleteflag = redeleteflag;
    }
    
    public String getRememo() {
        return rememo;
    }
    
    public void setRememo(String rememo) {
        this.rememo = rememo;
    }
    
    public String getRedate() {
        return redate;
    }
    
    public void setRedate(String redate) {
        this.redate = redate;
    }
    
}
